import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Volume2, VolumeX, Pause, Play } from "lucide-react";

interface ArticleReaderProps {
  sections: { heading: string; paragraphs: string[] }[];
  title: string;
}

const ArticleReader = ({ sections, title }: ArticleReaderProps) => {
  const [isReading, setIsReading] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [supported, setSupported] = useState(true);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  // Fix Bug 1: interval ref to keep Chrome speech alive past ~14s
  const resumeIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  // Fix Bug 4: track pending voiceschanged listener so we can remove it
  const pendingListenerRef = useRef<(() => void) | null>(null);

  const clearResumeInterval = () => {
    if (resumeIntervalRef.current !== null) {
      clearInterval(resumeIntervalRef.current);
      resumeIntervalRef.current = null;
    }
  };

  const clearPendingListener = () => {
    if (pendingListenerRef.current) {
      window.speechSynthesis.removeEventListener("voiceschanged", pendingListenerRef.current);
      pendingListenerRef.current = null;
    }
  };

  useEffect(() => {
    if (!("speechSynthesis" in window)) {
      setSupported(false);
    }
    return () => {
      clearResumeInterval();
      clearPendingListener();
      window.speechSynthesis?.cancel();
    };
  }, []);

  // Reset on content change
  useEffect(() => {
    clearResumeInterval();
    clearPendingListener();
    window.speechSynthesis?.cancel();
    setIsReading(false);
    setIsPaused(false);
  }, [title]);

  const handleStart = useCallback(() => {
    const fullText = sections
      .map((s) => `${s.heading}. ${s.paragraphs.join(". ")}`)
      .join(". ");

    // Fix Bug 4: remove any dangling listener from a previous attempt
    clearPendingListener();
    clearResumeInterval();
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(fullText);
    utterance.lang = "id-ID";
    utterance.rate = 0.95;
    utterance.pitch = 1;

    utterance.onend = () => {
      clearResumeInterval();
      setIsReading(false);
      setIsPaused(false);
    };

    // Fix Bug 3: ignore "interrupted" — it fires when we cancel() intentionally
    utterance.onerror = (e) => {
      if ((e as SpeechSynthesisErrorEvent).error === "interrupted") return;
      clearResumeInterval();
      setIsReading(false);
      setIsPaused(false);
    };

    utteranceRef.current = utterance;

    const doSpeak = () => {
      const voices = window.speechSynthesis.getVoices();
      const idVoice =
        voices.find((v) => v.lang.startsWith("id")) ||
        voices.find((v) => v.lang.startsWith("ms"));
      if (idVoice) utterance.voice = idVoice;

      setTimeout(() => {
        // Fix Bug 5 (root cause): Chrome kadang mulai dengan paused=true
        // — resume() wajib dipanggil sebelum speak(), kalau tidak suara tidak keluar sama sekali
        window.speechSynthesis.resume();
        window.speechSynthesis.speak(utterance);

        // Fix Bug 1: Chrome silently stops after ~14s — pause+resume every 10s to keep it alive
        resumeIntervalRef.current = setInterval(() => {
          if (!window.speechSynthesis.speaking) {
            clearResumeInterval();
            return;
          }
          if (!window.speechSynthesis.paused) {
            window.speechSynthesis.pause();
            window.speechSynthesis.resume();
          }
        }, 10000);
      }, 150);
    };

    setIsReading(true);
    setIsPaused(false);

    if (window.speechSynthesis.getVoices().length > 0) {
      doSpeak();
    } else {
      // Fix Bug 4: store reference so it can be cleaned up if needed
      pendingListenerRef.current = doSpeak;
      window.speechSynthesis.addEventListener("voiceschanged", doSpeak, { once: true });

      // Fix Bug 5b: fallback jika voiceschanged tidak pernah fire (beberapa browser/OS)
      setTimeout(() => {
        if (pendingListenerRef.current === doSpeak) {
          clearPendingListener();
          doSpeak();
        }
      }, 1000);
    }
  }, [sections]);

  const handlePause = () => {
    if (isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
    } else {
      window.speechSynthesis.pause();
      setIsPaused(true);
    }
  };

  const handleStop = () => {
    clearResumeInterval();
    clearPendingListener();
    window.speechSynthesis.cancel();
    setIsReading(false);
    setIsPaused(false);
  };

  if (!supported) return null;

  return (
    <div className="mb-8">
      <AnimatePresence mode="wait">
        {!isReading ? (
          <motion.button
            key="start"
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            onClick={handleStart}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-primary/10 hover:bg-primary/20 text-primary rounded-lg font-body text-sm font-medium transition-colors border border-primary/20"
          >
            <Volume2 className="w-4 h-4" />
            Dengarkan Artikel
          </motion.button>
        ) : (
          <motion.div
            key="controls"
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            className="flex items-center gap-3 px-4 py-2.5 bg-card border border-border rounded-lg"
          >
            <button
              onClick={handlePause}
              className="w-8 h-8 flex items-center justify-center rounded-full bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
            >
              {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={handleStop}
              className="w-8 h-8 flex items-center justify-center rounded-full bg-muted hover:bg-border text-muted-foreground transition-colors"
              title="Berhenti"
            >
              <VolumeX className="w-3.5 h-3.5" />
            </button>
            <div className="ml-1">
              <p className="text-xs font-body text-muted-foreground">
                {isPaused ? "Dijeda" : "Membacakan artikel..."}
              </p>
              <p className="text-xs font-body text-foreground font-medium truncate max-w-[200px]">
                {title}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ArticleReader;
